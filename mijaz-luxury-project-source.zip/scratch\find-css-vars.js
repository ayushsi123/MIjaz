import fs from 'fs';

const cssContent = fs.readFileSync('replit-index.css', 'utf8');

// Match custom properties --[a-zA-Z0-9-]+: [^;]+
const matches = cssContent.match(/--[a-zA-Z0-9-]+:[^;}]+/g) || [];
const uniqueVars = Array.from(new Set(matches));

console.log('--- REPLIT CSS CUSTOM PROPERTIES ---');
uniqueVars.forEach(v => {
  if (v.includes('color') || v.includes('font') || v.includes('background') || v.includes('foreground')) {
    console.log(v.trim());
  }
});
