import fs from 'fs';

const jsContent = fs.readFileSync('replit-index.js', 'utf8');

// Check for component names and headers in the Replit minified bundle
const targets = [
  'Shop by Category',
  'Shop by Scent Profile',
  'Exclusive / Signature Blends',
  'Specials / Recommended',
  'Solid Perfume',
  'Hair & Body Mist',
  'Discovery Wardrobe',
  'The Royal Dual',
  'Oud Signature',
  'Floral Trio',
  'Cormorant Upright',
  'Cinzel',
  'DM Sans'
];

console.log('--- REPLIT BUNDLE ANALYSIS ---');
targets.forEach(target => {
  const index = jsContent.indexOf(target);
  if (index !== -1) {
    console.log(`Found: "${target}" at index ${index} (Context: "${jsContent.substring(index - 40, index + 80).replace(/\n/g, ' ')}")`);
  } else {
    console.log(`NOT Found: "${target}"`);
  }
});
