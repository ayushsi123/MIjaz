import fs from 'fs';
import readline from 'readline';

const transcriptPath = '../../brain/dc01f584-c718-46de-ab99-9aca7488b9bd/.system_generated/logs/transcript_full.jsonl';

const fileStream = fs.createReadStream(transcriptPath);

const rl = readline.createInterface({
  input: fileStream,
  crlfDelay: Infinity
});

console.log('Searching transcript_full.jsonl...');

rl.on('line', (line) => {
  try {
    const step = JSON.parse(line);
    
    // Check if it's a VIEW_FILE tool response or CODE_ACTION or PLANNER_RESPONSE
    if (step.type === 'VIEW_FILE' && step.content && step.content.includes('File Path:')) {
      const pathMatch = step.content.match(/File Path: `file:\/\/\/(.*)`/);
      if (pathMatch) {
        const filePath = pathMatch[1];
        if (filePath.endsWith('Home.tsx') || filePath.endsWith('index.css') || filePath.endsWith('Gifting.tsx')) {
          console.log(`\n=== Found View of ${filePath} at step ${step.step_index} ===`);
          console.log(step.content.substring(0, 500) + '...');
        }
      }
    }
    
    if (step.type === 'USER_INPUT' && step.content && step.content.includes('<USER_REQUEST>')) {
      console.log(`\n[Step ${step.step_index}] USER INPUT: ${step.content}`);
    }
  } catch (e) {
    // Ignore invalid JSON lines
  }
});
