// Automatically checks the Shopify cart total and applies dynamic notifications/calculations
document.addEventListener('DOMContentLoaded', () => {
  const CART_DISCOUNT_THRESHOLD = 2499; // Rs. 2499
  
  const onCartChange = (cart) => {
    // Discount is removed
    const discountLabel = document.querySelector('.cart-discount-label');
    if (discountLabel) discountLabel.style.display = 'none';
  };

  // Bind to Shopify cart change fetch requests
  const originalFetch = window.fetch;
  window.fetch = async function(...args) {
    const response = await originalFetch.apply(this, args);
    if (args[0] && (args[0].includes('/cart/add') || args[0].includes('/cart/change') || args[0].includes('/cart/clear') || args[0].includes('/cart/update'))) {
      const clone = response.clone();
      try {
        const cart = await clone.json();
        onCartChange(cart);
      } catch (e) {
        // Fallback
      }
    }
    return response;
  };
});
