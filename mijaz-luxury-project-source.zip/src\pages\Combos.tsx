import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useCart } from "../hooks/useCart";
import { PRODUCTS } from "../data/products";
import { Check, ShoppingBag } from "lucide-react";
import perfume50ml from "../imports/perfume-50ml.jpg";

const SANS = { fontFamily: "'DM Sans', sans-serif" } as const;
const CINZEL = { fontFamily: "'Cinzel', serif" } as const;

interface GiftComboItem {
  productId: number;
  size: string;
}

interface GiftCombo {
  id: number;
  name: string;
  description: string;
  items: GiftComboItem[];
  img: string;
}

const PRESET_COMBOS: GiftCombo[] = [
  {
    id: 101,
    name: "The Royal Dual Combo",
    description: "Our signature blend in spray & oil formats for dual layering. Yields unparalleled 24-hour presence.",
    items: [
      { productId: 1, size: "50ml" }, // Gulzaar 50ml -> 600
      { productId: 12, size: "8ml" }   // Gulzaar Oil 8ml -> 350
    ],
    img: perfume50ml
  },
  {
    id: 102,
    name: "Oud Signature Set",
    description: "An pairing of our premium woody blends. Perfect for couples or connoisseurs of fine oud.",
    items: [
      { productId: 1, size: "50ml" }, // Gulzaar 50ml -> 600
      { productId: 7, size: "50ml" }  // Rooh 50ml -> 600
    ],
    img: perfume50ml
  },
  {
    id: 103,
    name: "The Discovery Wardrobe",
    description: "An elegant sampler casket containing 5 of our finest scent profiles in travel-ready roll-ons.",
    items: [
      { productId: 12, size: "8ml" },  // Gulzaar Oil -> 350
      { productId: 13, size: "8ml" }, // Rooh Oil -> 350
      { productId: 14, size: "8ml" }, // Amaya Oil -> 350
      { productId: 15, size: "8ml" }, // Surkhab Oil -> 350
      { productId: 16, size: "8ml" }  // Siara Oil -> 350
    ],
    img: perfume50ml
  },
  {
    id: 104,
    name: "Floral Trio Collection",
    description: "A bright, romantic garden collection of our feminine floral blends.",
    items: [
      { productId: 2, size: "20ml" }, // Gustakhiyan 20ml -> 350
      { productId: 3, size: "20ml" }, // Samirah 20ml -> 350
      { productId: 6, size: "20ml" }  // Siara 20ml -> 350
    ],
    img: perfume50ml
  }
];

export function Combos() {
  const addToCart = useCart((state) => state.addToCart);
  const navigate = useNavigate();
  const [selectedCombo, setSelectedCombo] = useState<GiftCombo>(PRESET_COMBOS[0]);
  const [addedComboId, setAddedComboId] = useState<number | null>(null);

  // Helper: Resolve combo price by summing constituent catalog prices and applying a flat Rs. 50 discount
  const getComboPrice = (combo: GiftCombo) => {
    const base = combo.items.reduce((sum, item) => {
      const prod = PRODUCTS.find((p) => p.id === item.productId);
      if (!prod) return sum;
      const price = prod.salePrices[item.size] ?? prod.prices[item.size] ?? 0;
      return sum + price;
    }, 0);
    return base - 50;
  };

  // Helper: Get descriptive names of included items
  const getComboItemLabels = (combo: GiftCombo) => {
    return combo.items.map((item) => {
      const prod = PRODUCTS.find((p) => p.id === item.productId);
      if (!prod) return `${item.size} Unknown Item`;
      return `${item.size} ${prod.name} ${prod.category === "Oil" ? "Oil" : "Spray"}`;
    });
  };

  const handleAddComboToCart = (combo: GiftCombo) => {
    const comboPrice = getComboPrice(combo);
    const itemNames = getComboItemLabels(combo);

    // Adapter mock object to fit the cart store structure
    const productAdapter = {
      id: combo.id,
      name: combo.name,
      category: "Gift Set",
      gender: "Unisex",
      occasion: "Gifting",
      sizes: ["Standard Set"],
      prices: { "Standard Set": comboPrice * 1.2 },
      salePrices: { "Standard Set": comboPrice },
      notes: ["Rose", "Oud", "Musk"],
      img: combo.img,
      description: combo.description
    };

    const giftingConfig = {
      isGift: true,
      recipientName: "Gift Receiver",
      senderName: "Gift Sender",
      message: "Enjoy this curated fragrance set!",
      packaging: "Standard Cardboard Box"
    };

    addToCart(productAdapter as any, "Standard Set", giftingConfig);
    setAddedComboId(combo.id);
    
    setTimeout(() => {
      setAddedComboId(null);
      navigate("/cart");
    }, 800);
  };

  return (
    <div className="bg-[#FAF8F4] min-h-screen py-12" style={SANS}>
      <div className="max-w-[1440px] mx-auto px-6">
        
        {/* Header */}
        <div className="text-center mb-16 pt-8">
          <p className="text-[#D4AF37] text-[10px] tracking-[0.35em] uppercase mb-3 font-bold" style={SANS}>Curated Caskets</p>
          <h1 className="text-4xl md:text-5xl font-normal text-gray-900 mb-4 tracking-wide" style={CINZEL}>
            Luxury Combo Sets
          </h1>
          <p className="text-gray-500 text-sm max-w-xl mx-auto leading-relaxed">
            Discover our handpicked collection of fragrance pairings and travel wardrobes, priced strictly as the sum of their individual catalog prices.
          </p>
        </div>

        {/* Combos Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {PRESET_COMBOS.map((combo) => {
            const isSelected = selectedCombo.id === combo.id;
            const isAdding = addedComboId === combo.id;
            const comboPrice = getComboPrice(combo);
            const comboItems = getComboItemLabels(combo);
            
            return (
              <div 
                key={combo.id}
                onClick={() => setSelectedCombo(combo)}
                className={`bg-white border rounded-2xl overflow-hidden hover:shadow-md transition-all duration-300 flex flex-col justify-between cursor-pointer ${
                  isSelected ? "border-[#800000] ring-1 ring-[#800000]" : "border-gray-100"
                }`}
              >
                {/* Image */}
                <div className="relative aspect-square bg-[#f5f3f0] overflow-hidden">
                  <img 
                    src={combo.img} 
                    alt={combo.name} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" 
                  />
                  <span className="absolute top-3 left-3 bg-[#D4AF37] text-black text-[8px] font-bold px-2 py-0.5 uppercase tracking-widest rounded-md">
                    Combo Set
                  </span>
                </div>

                {/* Details */}
                <div className="p-5 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="font-semibold text-sm text-gray-900 mb-1" style={CINZEL}>
                      {combo.name}
                    </h3>
                    <p className="text-[10px] text-gray-400 leading-relaxed mb-4">
                      {combo.description}
                    </p>
                    
                    {/* Items List */}
                    <div className="space-y-1 mb-6">
                      <p className="text-[9px] font-bold text-[#800000] uppercase tracking-wider mb-1">What's Inside:</p>
                      {comboItems.map((item, idx) => (
                        <div key={idx} className="flex items-start gap-1 text-[9px] text-gray-500">
                          <Check size={10} className="text-[#D4AF37] shrink-0 mt-0.5" />
                          <span>{item}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Price & Action */}
                  <div className="pt-4 border-t border-gray-50 flex items-center justify-between">
                    <div>
                      <p className="text-[9px] text-gray-400 uppercase tracking-wider">Price</p>
                      <p className="text-xs font-bold text-gray-900">Rs. {comboPrice.toLocaleString()}</p>
                    </div>
                    
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleAddComboToCart(combo);
                      }}
                      disabled={isAdding}
                      className="bg-[#800000] hover:bg-[#D4AF37] text-white hover:text-black py-2 px-3.5 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-colors flex items-center gap-1.5 cursor-pointer"
                    >
                      {isAdding ? (
                        <>
                          <Check size={11} /> Added
                        </>
                      ) : (
                        <>
                          <ShoppingBag size={11} /> Add to Cart
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </div>
  );
}
